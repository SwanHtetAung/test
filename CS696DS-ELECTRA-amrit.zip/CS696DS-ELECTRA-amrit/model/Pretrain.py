import os, sys, random

from pathlib import Path
from functools import partial
from datetime import datetime, timezone, timedelta
from IPython.core.debugger import set_trace as bk
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import torch.tensor as T
import datasets
from datasets import Dataset
from fastai.text.all import *
from transformers import ElectraConfig, ElectraTokenizerFast, ElectraForMaskedLM, ElectraForPreTraining
from hugdatafast import *
from ELECTRALoss import ELECTRALoss
from ELECTRAModel import ELECTRAModel
from _utils.SpanMasking import mask_tokens
from _utils.ArgParser import get_parser
from _utils.ELectraDataProcessor import ELECTRADataProcessor
from _utils.utils import MyConfig, Adam_no_bias_correction, linear_warmup_and_then_decay, RunSteps, \
    GradientClipping, linear_warmup_and_decay

# Create the argument parser
parser = get_parser()
args = parser.parse_args()
# print(f'Passed arguments: {args}')
# sys.exit(0)
# Create a configuration
config = MyConfig({
    'device': 'cuda:0' if not args.use_cpu else "cpu",
    'base_run_name': 'vanilla',  # run_name = {base_run_name}_{seed}
    'seed': 11081,
    'adam_bias_correction': False,
    'schedule': 'original_linear',
    'sampling': 'fp32_gumbel',
    'mask_style': args.mask_style,
    'electra_mask_style': True,
    'gen_smooth_label': False,
    'disc_smooth_label': False,
    'size': args.model_size,
    'logger': 'wandb',
    'num_workers': 3,
    'dataset_type': args.dataset_type,
    'train_dataset_path': args.train_dataset_path,
    'val_dataset_path': args.val_dataset_path,
    'datas': ['openwebtext', 'wikipedia'],
    'tokenized_cache_dir': args.tokenized_cache_dir,
})

# %%
# Check and Default
assert config.sampling in ['fp32_gumbel', 'fp16_gumbel', 'multinomial']
assert config.schedule in ['original_linear', 'separate_linear', 'one_cycle', 'adjusted_one_cycle']
assert config.logger in ['wandb', 'neptune', None, False]
if not config.base_run_name: config.base_run_name = str(datetime.now(timezone(timedelta(hours=+8))))[6:-13].replace(' ',
                                                                                                                    '').replace(
    ':', '').replace('-', '')
if not config.seed: config.seed = random.randint(0, 999999)
config.run_name = f'{config.base_run_name}_{config.seed}'
if config.gen_smooth_label is True: config.gen_smooth_label = 0.1
if config.disc_smooth_label is True: config.disc_smooth_label = 0.1

# Setting of different sizes
i = ['small', 'base', 'large'].index(config.size)
config.mask_prob = [0.15, 0.15, 0.25][i]
config.lr = [5e-4, 2e-4, 2e-4][i]
config.batch_size = [128, 256, 2048][i] if not args.batch_size else int(args.batch_size)
config.steps = [10 ** 6, 766, 400 * 1000][i] if not args.steps else int(args.steps)
config.max_length = [128, 512, 512][i]
generator_size_divisor = [4, 3, 4][i]
disc_config = ElectraConfig.from_pretrained(f'google/electra-{config.size}-discriminator')
gen_config = ElectraConfig.from_pretrained(f'google/electra-{config.size}-generator')
# note that public electra-small model is actually small++ and don't scale down generator size 
gen_config.hidden_size = int(disc_config.hidden_size / generator_size_divisor)
gen_config.num_attention_heads = disc_config.num_attention_heads // generator_size_divisor
gen_config.intermediate_size = disc_config.intermediate_size // generator_size_divisor

# logger
if config.logger == 'wandb':
    import wandb
    from fastai.callback.wandb import WandbCallback

print("configuration", config)

Path('./datasets', exist_ok=True)
Path('./checkpoints/pretrain').mkdir(exist_ok=True, parents=True)
edl_cache_dir = Path("./datasets/electra_dataloader")
edl_cache_dir.mkdir(exist_ok=True)

print(f"process id: {os.getpid()}")

hf_tokenizer = ElectraTokenizerFast.from_pretrained(f"google/electra-{config.size}-generator")
ELECTRAProcessor = partial(ELECTRADataProcessor, hf_tokenizer=hf_tokenizer, max_length=512)
dsets = []
# Load a sample Dataset
if config.dataset_type == "subsampled":
    if config.train_dataset_path:
        df_train = pd.read_csv(config.train_dataset_path)
        df_train.columns = ['text']
        data_train = Dataset.from_pandas(df_train)
        processed_train = ELECTRAProcessor(data_train).map(num_proc=1) # cache_file_name=f"sampled_train_{config.max_length}.arrow",
        dsets.append(processed_train)
        if config.val_dataset_path:
            df_valid = pd.read_csv(config.val_dataset_path)
            df_valid.columns = ['text']
            data_valid = Dataset.from_pandas(df_valid)
            processed_valid = ELECTRAProcessor(data_valid).map(num_proc=1) # cache_file_name=f"sampled_valid_{config.max_length}.arrow",
        merged_dsets = {'train': datasets.concatenate_datasets(dsets)}
else:
    # Wikipedia
    if 'wikipedia' in config.datas:
        print('load/download wiki datasets')
        wiki = datasets.load_dataset('wikipedia', '20200501.en', cache_dir=config.dataset_cache_dir)['train']
        print('load/create data from wiki datasets for ELECTRA')
        e_wiki = ELECTRAProcessor(wiki).map(cache_file_name=f"electra_wiki_{config.max_length}.arrow", num_proc=1)
        dsets.append(e_wiki)
    if 'openwebtext' in config.datas:
        print('load/download OpenWebText Corpus')
        owt = datasets.load_dataset('openwebtext', cache_dir=config.dataset_cache_dir)['train']
        print('load/create data from OpenWebText Corpus for ELECTRA')
        e_owt = ELECTRAProcessor(owt, apply_cleaning=False).map(
            cache_file_name=f"electra_owt_{config.max_length}.arrow", num_proc=1)
        dsets.append(e_owt)
        merged_dsets = {'train': datasets.concatenate_datasets(dsets)}

hf_dsets = HF_Datasets(merged_dsets, cols={'input_ids': TensorText, 'sentA_length': noop},
                       hf_toker=hf_tokenizer, n_inp=2)
dls = hf_dsets.dataloaders(
    bs=config.batch_size,
    num_workers=config.num_workers,
    pin_memory=False,
    shuffle_train=True,
    srtkey_fc=False,
    cache_dir=config.tokenized_cache_dir,
    cache_name='dl_{split}.json'
    )


class MaskedLMCallback(Callback):
    @delegates(mask_tokens)
    def __init__(self, tokenizer, ignore_index=-100, for_electra=False, **kwargs):
        self.ignore_index = ignore_index
        self.for_electra = for_electra
        self.mask_tokens = partial(mask_tokens, mask_ratio=0.15, tokenizer=tokenizer)

    def before_batch(self):
        input_ids, sentA_lengths = self.xb
        masked_inputs, span_boundary, labels, positional_embedding, is_mlm_applied = self.mask_tokens(input_ids)
        if self.for_electra:
            self.learn.xb, self.learn.yb = (masked_inputs, sentA_lengths, is_mlm_applied, labels), (labels,)
        else:
            self.learn.xb, self.learn.yb = (masked_inputs, sentA_lengths), (labels,)

    @delegates(TfmdDL.show_batch)
    def show_batch(self, dl, idx_show_ignored, verbose=True, **kwargs):
        b = dl.one_batch()
        input_ids, sentA_lengths = b
        masked_inputs, _, labels, _, is_mlm_applied = self.mask_tokens(input_ids.clone())
        labels[labels == self.ignore_index] = idx_show_ignored
        # some notice to help understand the masking mechanism
        if verbose:
            print("We won't count loss from position where y is ignore index")
            print("Notice 1. Positions have label token in y will be either [Mask]/other token/orginal token in x")
            print("Notice 2. Special tokens (CLS, SEP) won't be masked.")
            print("Notice 3. Dynamic masking: every time you run gives you different results.")
        # show
        tfm_b = (masked_inputs, sentA_lengths, is_mlm_applied, labels) if self.for_electra else (
        masked_inputs, sentA_lengths, labels)
        # dl.show_batch(b=tfm_b, **kwargs)


mlm_cb = MaskedLMCallback(tokenizer=hf_tokenizer,
                          for_electra=True)

# Seed & PyTorch benchmark
torch.backends.cudnn.benchmark = True
dls[0].rng = random.Random(config.seed)  # for fastai dataloader
random.seed(config.seed)
np.random.seed(config.seed)
torch.manual_seed(config.seed)

generator = ElectraForMaskedLM(gen_config)
discriminator = ElectraForPreTraining(disc_config)
discriminator.electra.embeddings = generator.electra.embeddings
generator.generator_lm_head.weight = generator.electra.embeddings.word_embeddings.weight

# ELECTRA training loop
electra_model = ELECTRAModel(generator, discriminator, hf_tokenizer)
electra_loss_func = ELECTRALoss(gen_label_smooth=config.gen_smooth_label, disc_label_smooth=config.disc_smooth_label)

# Optimizer
if config.adam_bias_correction:
    opt_func = partial(Adam, eps=1e-6, mom=0.9, sqr_mom=0.999, wd=0.01)
else:
    opt_func = partial(Adam_no_bias_correction, eps=1e-6, mom=0.9, sqr_mom=0.999, wd=0.01)

# Learning rate shedule
if config.schedule.endswith('linear'):
    lr_shed_func = linear_warmup_and_then_decay if config.schedule == 'separate_linear' else linear_warmup_and_decay
    lr_shedule = ParamScheduler({'lr': partial(linear_warmup_and_decay,
                                               lr_max=config.lr,
                                               warmup_steps=10000,
                                               total_steps=config.steps, )})

# Learner

dls.to(torch.device(config.device))
learn = Learner(dls, electra_model,
                loss_func=electra_loss_func,
                opt_func=opt_func,
                path='./checkpoints',
                model_dir='pretrain',
                cbs=[mlm_cb,
                     RunSteps(config.steps, [0.0625, 0.125, 0.25, 0.5, 1.0], config.run_name + "_{percent}"),
                     ],
                )

# logging

if config.logger == 'wandb':
    wandb.init(name=config.run_name, project='electra_pretrain', config={**config})
    learn.add_cb(WandbCallback(log_preds=False, log_model=False))

# Mixed precison and Gradient clip
# learn.to_native_fp16(init_scale=2.**11)
learn.add_cb(GradientClipping(1.))

# Print time and run name
print(f"trial , starts at {datetime.now()}")

# Run
if config.schedule == 'one_cycle':
    learn.fit_one_cycle(9999, lr_max=config.lr)
elif config.schedule == 'adjusted_one_cycle':
    learn.fit_one_cycle(9999, lr_max=config.lr, div=1e5, pct_start=10000 / config.steps)
else:
    learn.fit(9999, cbs=[lr_shedule])
