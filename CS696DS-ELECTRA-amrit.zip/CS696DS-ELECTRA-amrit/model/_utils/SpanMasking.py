import math
import numpy as np
import torch


def geo_metric(p,lower,upper):
    len_distrib = [p * (1-p)**(i - lower) for i in range(lower, upper + 1)] if p >= 0 else None
    len_distrib = [x / (sum(len_distrib)) for x in len_distrib]
    lens = list(range(lower, upper + 1))
    return len_distrib,lens


def helper_word_index(tokenized_text, cls_token, sep_token):
    """
    :type toeknized_text: List[List[int]]
    :type: cls_token :String : ['CLS']
    :type: sep_token :String : ['SEP']
    rtype: res : tokenizded_text interval  for each word in the tokenized_text
    """
    res=[]
    for x in range(len(tokenized_text)):
        i=tokenized_text[x]
        if len(i) >=3 and i[0] =='#' and i[1] =="#":
            if len(res)==0:
                res.append(x)
            else:
                res[-1].append(x)
        elif i != cls_token and i != sep_token:
            res.append([x])
    return res
def merge_intervals(intervals):
    """
    :type intervals: List[List[int]]
    :rtype: List[List[int]]
    """
    merge=[]
    sort_intervals=sorted(intervals, key=lambda x : x[0])
    for i in sort_intervals:
        if len(merge) !=0 and merge[-1][-1] >= i [0]:
            merge[-1] = [merge[-1][0],max(merge[-1][-1],i[-1])]
        else:
            merge.append(i)
    return merge
 
def mask_tokens(tokens_ids, mask_ratio, tokenizer):

    """
    Token_ids : Input type of [B,Sentence] B= Batch size, Sentence= Training data sentence 
    mask_raito : Double [0,1]
    Tokenizer: Span Tokenizer, Bert Tokenizer
    Return Mask Token, External_label, Ground Truth, Postional_Encodings and MlM_masks for MLM loss function
    """
    # print("Receiving:", tokens_ids)
    labels = tokens_ids.clone()
    device = tokens_ids.device
    # dummy mlm_mask
    inputs, labels, external_boundary, positional_encodings, mlm_masks = [], [], [], [], []
    for token_ids in tokens_ids:
      tokens = tokenizer.convert_ids_to_tokens(token_ids)
      if mask_ratio > 1:
        print('mask_ratio mush be less than 1')
        return
    ### The paper in SPAN BERT uses Geometric distrbution with probablity of 0.2, where the minimum Span Length is 1 and the max is 10
      dis,lens = geo_metric(0.2,1,10)
      probability_matrix = torch.full(token_ids.shape, False, device=device)
      tokenized_text = tokens
      sentence = helper_word_index(tokenized_text, tokenizer.cls_token, tokenizer.sep_token)
      length_sentence = len(sentence)
      mask_budget = math.ceil(mask_ratio * length_sentence)
      lower_limit=0
      upper_limit = length_sentence-1
      target = sentence
      interval=[]
      while mask_budget >0:
          mask_length = np.random.choice(lens,p=dis)
          if mask_length > mask_budget:
              mask_length= mask_budget
          start = np.random.randint(0,length_sentence)
          end = start+mask_length-1 if start+mask_length-1 <=upper_limit else upper_limit
          interval.append([sentence[start][0],sentence[end][-1]])
          mask_budget -=mask_length
      spans = merge_intervals(interval)
      for start,end in spans:
          rand = np.random.random()
          for i in range(start,end+1):
              if rand< 0.8:
                  tokenized_text[i]=tokenizer.mask_token
              elif rand<0.9:
                  tokenized_text[i]=np.random.choice(tokenized_text)
      paper_span=[]
      pe=[]
      for i in spans:
          paper_span.append([i[0]-1,i[1]+1])
      for j in spans:
          temp=[]
          temp_start= j[0]
          for k in range(j[0],j[1]+1):
              temp.append(k-temp_start+1) ## Postional Embedding, If the emebed boundary is between [5,8] it shall return [1,2] realtive to the embedded boundary
              probability_matrix[k]=True
          pe.append(temp)
          temp=[]
      mlm_mask = probability_matrix
      mlm_masks.append(mlm_mask)
      inputs.append(tokenizer.convert_tokens_to_ids(tokenized_text))
      external_boundary.append(paper_span)
      labels.append(token_ids)
      positional_encodings.append(pe)
    # print("Mask_tokens finished")
    return torch.as_tensor(inputs, device=device), external_boundary, torch.stack(labels), positional_encodings, torch.stack(mlm_masks)

