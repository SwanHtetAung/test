import argparse


def get_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_type", default="subsampled", help="Train on Subsampled or full")
    parser.add_argument("--dataset_cache_dir", default=None, help="path which stores the downloaded full datasets")
    parser.add_argument("--train_dataset_path", default=None, help="location of the training datasets")
    parser.add_argument("--val_dataset_path", default=None, help="location of the validation datasets")
    parser.add_argument("--use_cpu", default=None, help="GPU or CPU Training")
    parser.add_argument("--mask_style", default="span", help="random_masking or span_masking")
    parser.add_argument("--model_size", default="base", help="The size of the ELECTRA model")
    parser.add_argument("--tokenized_cache_dir", default='./datasets/electra_dataloader', help="directory which stores the "
                                                                                     "tokenized data")
    parser.add_argument("--batch_size", help='batch size for the training')
    parser.add_argument("--steps", help='Steps to be executed')
    return parser
